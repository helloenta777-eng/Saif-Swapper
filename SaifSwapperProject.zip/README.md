# Saif Swapper Android project

This is the source project for the Android app **Saif Swapper**. It is not a compiled APK.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync. Use JDK 17 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## What the app does
- Android interface with a checklist and local notes.
- Opens TikTok and TikTok's username-help page.
- Does not collect credentials or use TikTok automation.

## Limitations
It cannot automatically transfer, reserve, or guarantee a username. TikTok may temporarily prevent a released username from being reused. This project does not contain a compiled APK; building requires Android Studio and the Android SDK.
