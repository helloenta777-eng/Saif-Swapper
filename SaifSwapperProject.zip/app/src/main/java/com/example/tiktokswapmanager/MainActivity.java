package com.example.tiktokswapmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root, checklist;
    private SharedPreferences prefs;
    private final String[] keys = {
        "target_ready", "replacement_chosen", "source_changed",
        "claim_attempted", "claim_succeeded"
    };
    private final String[] labels = {
        "Confirm you can access the target account",
        "Choose a replacement username for the source account",
        "Manually change the source account username",
        "Try claiming @elmt on the target account",
        "Confirm the target account now owns @elmt"
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("swap_manager", MODE_PRIVATE);
        buildUi();
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setTextColor(0xFF202124);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private Button button(String s, Runnable action) {
        Button b = new Button(this);
        b.setText(s);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        scroll.addView(root);
        setContentView(scroll);

        root.addView(text("Saif Swapper", 24, true));
        root.addView(text("Guided manual workflow for @elmt", 16, false));
        root.addView(text("Important: this app does not log in to TikTok, change usernames automatically, reserve handles, or bypass TikTok restrictions. A transfer is not guaranteed.", 15, false));

        root.addView(button("Safety checklist", () -> new AlertDialog.Builder(this)
            .setTitle("Before you start")
            .setMessage("• Confirm both accounts are yours and accessible.\\n\\n• Choose a replacement username first.\\n\\n• TikTok may temporarily prevent a released username from being reused.\\n\\n• If keeping @elmt matters to you, do not release it unless you accept the risk.\\n\\n• Never share passwords, verification codes, or session cookies.")
            .setPositiveButton("OK", null).show()));

        root.addView(button("Open TikTok", () -> openUrl("https://www.tiktok.com/")));
        root.addView(button("Open TikTok username help", () -> openUrl("https://support.tiktok.com/en/getting-started/setting-up-your-profile/changing-your-username")));

        root.addView(text("Your checklist", 20, true));
        checklist = new LinearLayout(this);
        checklist.setOrientation(LinearLayout.VERTICAL);
        root.addView(checklist);
        renderChecklist();

        root.addView(text("Private notes (saved on this device)", 18, true));
        EditText notes = new EditText(this);
        notes.setHint("Optional notes — don't enter passwords or codes");
        notes.setMinLines(3);
        notes.setGravity(Gravity.TOP);
        notes.setText(prefs.getString("notes", ""));
        root.addView(notes);
        root.addView(button("Save notes", () -> {
            prefs.edit().putString("notes", notes.getText().toString()).apply();
            Toast.makeText(this, "Notes saved on this device", Toast.LENGTH_SHORT).show();
        }));
    }

    private void renderChecklist() {
        checklist.removeAllViews();
        for (int i = 0; i < keys.length; i++) {
            final String key = keys[i];
            CheckBox cb = new CheckBox(this);
            cb.setText(labels[i]);
            cb.setTextSize(15);
            cb.setChecked(prefs.getBoolean(key, false));
            cb.setPadding(0, dp(7), 0, dp(7));
            cb.setOnCheckedChangeListener((button, checked) ->
                prefs.edit().putBoolean(key, checked).apply());
            checklist.addView(cb);
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't open link", Toast.LENGTH_SHORT).show();
        }
    }
}
